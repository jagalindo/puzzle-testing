package fr.familiar.readers;

public class Trituple {
	
	public Object a,b,c;
	
	public Trituple(Object a, Object b, Object c){
		this.a=a;
		this.b=b;
		this.c=c;
	}
}
