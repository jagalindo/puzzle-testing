package fr.familiar.attributedfm;

public abstract class VariabilityElement {

	public abstract String getName();

}
